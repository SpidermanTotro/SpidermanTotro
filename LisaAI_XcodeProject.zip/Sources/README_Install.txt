
1. Open LisaAI.xcodeproj in Xcode
2. Ensure deployment target is iOS 16.0+
3. Add required permissions for Camera, Microphone, and Files
4. Build and run on physical device or simulator
5. For .ipa installation, export using Archive > Distribute App > Ad Hoc
