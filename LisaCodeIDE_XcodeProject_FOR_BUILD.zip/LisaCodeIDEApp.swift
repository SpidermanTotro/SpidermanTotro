
import SwiftUI

@main
struct LisaCodeIDEApp: App {
    var body: some Scene {
        WindowGroup {
            Text("LisaCode IDE Running")
                .font(.title)
                .padding()
        }
    }
}
